+++
date = "1987-10-23"
title = "About"
+++

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-135442428-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-135442428-1');
</script>

<center>**Office Automation Consultants, Inc.**</center>
<center>_**A Data Processing, Word Processing, and Telecommunications Firm based in New Orleans, Louisiana**_</center> 

![image](/img/oac-modern-logo.jpg)

>Office Automation Consultants Inc. was founded by **Vincent J. Ambrosia** in *1981*. 👨‍💻

Office Automation Consultants Inc. ("OAC") offers the highest quality software products and information technology services.💾  

- OAC provides: 
   - custom software development; 
   - systems integration, packaged software integration; 
   - I.T. consulting; 
   - web development; 
   - data processing related services and products.  

OAC has been serving the public and private sectors since 1981.  For over 30 years, OAC has been recognized for its application expertise by being selected as a business partner by major national vendors such as IBM, Digital Equipment, Honeywell, and Wang Laboratories.  

OAC's partnerships with clients develop solutions that reduce operating costs and increase productivity.
	
## Contact Office Automation Consultants, Inc. ✉️📞🏢📠

	-----------------------------
	Orleans Parish Office: 
	932 Hidalgo Street, Ste. 3, New Orleans, LA 70124   
    phone: (504) 400 - 9926
    -----------------------------
    Jefferson Parish Office: 
    8840 20th St., Kenner, LA 70062
    phone: (504) 467 - 8000
    -----------------------------
    email: oac@oacsoftware.com  

Since 1981 OAC has installed its software packages with customers including: 
Armed Services Board of Contract Appeals (U.S. Dept. of Defense)
United States Postal Service 
Loyola Marymount University, Los Angeles
Arkansas Supreme Court
Louisiana Supreme Court
Mississippi Supreme Court
New York Appellate Division 4th Judicial Department
New York Inspector General
Arkansas Court of Appeal
Louisiana Second Circuit Court of Appeal
Louisiana Third Circuit Court of Appeal
Louisiana Attorney General’s Office
Mississippi Public Service Commission
Jefferson Parish Sheriff’s Office
Orleans Parish District Attorney
Numerous Louisiana District Courts
Mississippi: Harrison County, Jackson County, and Lauderdale County etc.