+++
title = "Home"
description ="Office Automation Consultants, Inc. - Data Processing, Word Processing, Telecommunications"
+++

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-135442428-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-135442428-1');
</script>