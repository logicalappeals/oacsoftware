+++
title = "United States Postal Service"
description = "OAC writes Software to Automate, Track, and Maintain the USPS docket"
date = "2018-10-01"
tags = ["USPS","federal","court","OAC","software", "ACTS"]
+++

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-135442428-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-135442428-1');
</script>


![image](/img/usps-software-developer.jpg) 

<center>[Postal Service Board of Contract Appeals Decisions](https://about.usps.com/who/judicial/board-contract-appeals-decisions/)</center> 

> **Project Overview**: Office Automation Consultants, Inc. Automates Postal Service Board of Contract Appeals Decisions ("USPSBCA") Case Tracking Software

Functions Include:  

 - Report Generation
 - Document Generation
 - Case Tracking

