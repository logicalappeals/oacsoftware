 --- 
author: "Oac Inc." 
date: 2018-12-26 
title: Automated Case Tracking System
best: false 
tags: ["OAC","software","ACTS"] 
--- 
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-135442428-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-135442428-1');
</script>

# Automated Case Tracking System

## ACTS  

The Automated Case Tracking System

![image](/img/oac-modern-logo.jpg)

Office Automation Consultants Inc. developed its flagship product, the Automated Case Tracking System (ACTS), to serve as a flexible framework to manage all types of data in a variety of different environments.  The ACTS can be customized to suite the needs of any public or private agencies.  In addition to supporting the ACTS framework OAC also specializes in:

 - iOS, Android Development
 - Graphic/Multimedia Design
 - Cloud Networking
 - Systems Integration
 - Server Reporting Services
 - Web Design and Development
 - Database Design
 - Microsoft Office Integration


[Office Automation Consultants, Inc.](https://oacsoftware.com) is a Data Processing, Word Processing, and Telecommunications Firm based in New Orleans, LA. 🖥️ 👨‍💻   

You can learn more about the Firm by clicking [here](https://oacsoftware.com/about/). 

> email inquiries to oac@oacsoftware.com 

[See More Content](https://oacsoftware.com/blog/)



 