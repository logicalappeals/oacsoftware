+++
title= "License"
+++

>
> Copyright (c) Office Automation Consultants, Inc.<oac@oacsoftware.com>
>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-135442428-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-135442428-1');
</script>